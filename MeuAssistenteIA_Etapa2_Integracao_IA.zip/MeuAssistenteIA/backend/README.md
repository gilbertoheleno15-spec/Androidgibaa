# Backend de exemplo — Meu Assistente IA

Este serviço demonstra como ligar o aplicativo a um provedor de IA sem colocar a chave secreta dentro do APK.

## Requisitos
- Python 3.10+
- Uma chave de API do provedor de IA escolhido
- Um serviço de hospedagem com HTTPS para produção

## Instalação local
```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install fastapi uvicorn openai
```

Defina a variável `OPENAI_API_KEY` no ambiente do servidor e execute:
```bash
uvicorn main:app --host 0.0.0.0 --port 8000
```

## main.py
O endpoint `/chat` recebe `{ "message": "..." }` e devolve `{ "reply": "..." }`.
Configure no app o URL HTTPS público do endpoint `/chat`.

**Segurança:** não exponha o servidor local à internet sem HTTPS, autenticação, limites de uso e proteção contra abuso. Nunca coloque a chave de API no aplicativo Android.

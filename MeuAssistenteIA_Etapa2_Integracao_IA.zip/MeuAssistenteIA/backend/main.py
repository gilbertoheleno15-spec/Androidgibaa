import os
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from openai import OpenAI

app = FastAPI(title="Meu Assistente IA API")

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=8000)

@app.post("/chat")
def chat(payload: ChatRequest):
    key = os.getenv("OPENAI_API_KEY")
    if not key:
        raise HTTPException(status_code=503, detail="Servidor sem chave de IA configurada.")
    try:
        client = OpenAI(api_key=key)
        result = client.responses.create(
            model=os.getenv("OPENAI_MODEL", "gpt-4.1-mini"),
            input=payload.message
        )
        return {"reply": result.output_text}
    except Exception:
        raise HTTPException(status_code=502, detail="Não foi possível obter resposta da IA.")

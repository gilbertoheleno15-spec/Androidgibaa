# Meu Assistente IA — projeto Android inicial

Este é um projeto-base Android em Kotlin + Jetpack Compose, com interface escura inspirada em apps de conversa.

## O que já está implementado
- Interface com abas Conversa, Vídeos e Ferramentas.
- Entrada de voz em português usando o reconhecedor de fala disponível no Android.
- Leitura em voz alta das respostas com Text-to-Speech.
- Seleção de arquivo de vídeo pelo seletor do Android.
- Atalhos de ferramentas que preenchem uma solicitação na conversa.

## O que ainda precisa ser conectado
1. **IA online:** a conversa está em modo demonstrativo. Para respostas reais, implemente um backend HTTPS que receba a mensagem e chame o provedor de IA.
2. **Segurança:** não coloque uma chave de API secreta dentro do APK. Guarde-a no servidor.
3. **Pesquisa na internet:** implemente no backend uma ferramenta de busca e devolva fontes/links.
4. **Edição de vídeo:** a tela permite escolher um vídeo, mas cortes, legendas, desfoque e exportação ainda precisam ser implementados com um motor de edição.
5. **Permissões:** teste microfone e reconhecimento de voz em um aparelho Android real.

## Como abrir e gerar o APK
1. Instale o Android Studio em um computador.
2. Extraia este ZIP.
3. No Android Studio, escolha **Open** e selecione a pasta `MeuAssistenteIA`.
4. Aguarde a sincronização do Gradle.
5. Conecte um celular Android com depuração USB ou use um emulador.
6. Para testar, clique em **Run**.
7. Para gerar APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
8. O Android Studio mostrará o caminho do APK gerado.

## Configuração recomendada para a próxima etapa
Criar um backend HTTPS (por exemplo, com Kotlin/Ktor, Node.js ou Python/FastAPI) com um endpoint `/chat`. O app deverá enviar a mensagem ao backend, que fará a chamada autenticada à API de IA. O mesmo backend poderá coordenar transcrição, pesquisa e geração de roteiros.


## Etapa 2 — integração preparada
- Adicionado `AssistantApi.kt`, cliente Android para chamar um backend HTTPS.
- Adicionado `backend/main.py` e instruções para um backend FastAPI.
- O endpoint deve responder JSON no formato `{ "reply": "..." }`.
- Por segurança, a chave do provedor fica no servidor, nunca no APK.

**Ainda não é um APK final:** é necessário configurar o endereço HTTPS do backend, conectar o cliente à tela de conversa, implantar e proteger o servidor e então compilar/testar em Android Studio. A edição/exportação real de vídeo também é uma etapa posterior.

package com.meuassistenteia

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private val Ink = Color(0xFF10131A)
private val Panel = Color(0xFF1B202B)
private val Mint = Color(0xFF62D6B5)
private val Muted = Color(0xFF9AA4B2)

data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale("pt", "BR")
        }
        setContent { AssistantApp(onSpeak = { speak(it) }) }
    }

    private fun speak(text: String) { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "assistant_reply") }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssistantApp(onSpeak: (String) -> Unit) {
    val context = LocalContext.current
    var input by remember { mutableStateOf("") }
    var selectedTab by remember { mutableStateOf("Conversa") }
    var selectedVideo by remember { mutableStateOf("Nenhum vídeo selecionado") }
    val messages = remember {
        mutableStateListOf(
            ChatMessage("Olá! Sou o Meu Assistente IA. Posso conversar, ajudar com ideias para vídeos e organizar suas tarefas. Como posso ajudar?", false)
        )
    }

    val voiceLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) input = spoken
    }
    val videoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) selectedVideo = uri.lastPathSegment ?: "Vídeo selecionado"
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Mint,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Ink,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("Meu Assistente IA", fontWeight = FontWeight.Bold, fontSize = 19.sp)
                            Text("Seu espaço inteligente", color = Muted, fontSize = 11.sp)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Ink)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    listOf("Conversa", "Vídeos", "Ferramentas").forEach { tab ->
                        NavigationBarItem(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab },
                            icon = {
                                Icon(
                                    when (tab) {
                                        "Vídeos" -> Icons.Default.Movie
                                        "Ferramentas" -> Icons.Default.AutoAwesome
                                        else -> Icons.Default.Send
                                    }, contentDescription = tab
                                )
                            },
                            label = { Text(tab) }
                        )
                    }
                }
            }
        ) { padding ->
            when (selectedTab) {
                "Conversa" -> ChatScreen(
                    modifier = Modifier.padding(padding),
                    messages = messages,
                    input = input,
                    onInput = { input = it },
                    onSend = {
                        val prompt = input.trim()
                        if (prompt.isNotEmpty()) {
                            messages.add(ChatMessage(prompt, true))
                            messages.add(ChatMessage(
                                "Recebi sua mensagem. Para ativar respostas reais de IA, conecte um servidor seguro no projeto (veja o README). Não coloque sua chave de API diretamente no APK.",
                                false
                            ))
                            input = ""
                        }
                    },
                    onVoice = {
                        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
                            putExtra(RecognizerIntent.EXTRA_PROMPT, "Fale com seu assistente")
                        }
                        voiceLauncher.launch(intent)
                    },
                    onSpeak = onSpeak
                )
                "Vídeos" -> VideoScreen(
                    modifier = Modifier.padding(padding),
                    selectedVideo = selectedVideo,
                    onChoose = { videoLauncher.launch("video/*") }
                )
                else -> ToolsScreen(Modifier.padding(padding)) { tool ->
                    input = tool
                    selectedTab = "Conversa"
                }
            }
        }
    }
}

@Composable
fun ChatScreen(
    modifier: Modifier,
    messages: List<ChatMessage>,
    input: String,
    onInput: (String) -> Unit,
    onSend: () -> Unit,
    onVoice: () -> Unit,
    onSpeak: (String) -> Unit
) {
    Column(modifier.fillMaxSize().padding(horizontal = 14.dp)) {
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(messages) { msg ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (msg.fromUser) Arrangement.End else Arrangement.Start
                ) {
                    Column(
                        Modifier.widthIn(max = 310.dp)
                            .background(if (msg.fromUser) Color(0xFF24483F) else Panel, RoundedCornerShape(18.dp))
                            .padding(14.dp)
                    ) {
                        Text(msg.text, color = Color.White, fontSize = 14.sp)
                        if (!msg.fromUser) {
                            Text(
                                "Ouvir resposta",
                                color = Mint,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(top = 8.dp).clickable { onSpeak(msg.text) }
                            )
                        }
                    }
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            IconButton(onClick = onVoice, modifier = Modifier.background(Panel, CircleShape)) {
                Icon(Icons.Default.Mic, contentDescription = "Comando de voz", tint = Mint)
            }
            OutlinedTextField(
                value = input, onValueChange = onInput,
                modifier = Modifier.weight(1f),
                placeholder = { Text("Pergunte alguma coisa...", color = Muted) },
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Mint, unfocusedBorderColor = Panel,
                    focusedTextColor = Color.White, unfocusedTextColor = Color.White
                ),
                maxLines = 4
            )
            IconButton(onClick = onSend, modifier = Modifier.background(Mint, CircleShape)) {
                Icon(Icons.Default.Send, contentDescription = "Enviar", tint = Ink)
            }
        }
    }
}

@Composable
fun VideoScreen(modifier: Modifier, selectedVideo: String, onChoose: () -> Unit) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Estúdio de vídeos", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Prepare vídeos para Reels, Shorts e TikTok.", color = Muted)
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Default.Movie, tint = Mint, contentDescription = null, modifier = Modifier.size(34.dp))
                Text("Vídeo de origem", fontWeight = FontWeight.SemiBold)
                Text(selectedVideo, color = Muted, fontSize = 12.sp)
                Button(onClick = onChoose) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Escolher vídeo") }
            }
        }
        Text("Próximos recursos", fontWeight = FontWeight.Bold)
        FeatureRow("Cortes automáticos de 45 segundos")
        FeatureRow("Legendas dinâmicas com palavras destacadas")
        FeatureRow("Enquadramento vertical 9:16 e fundo desfocado")
        FeatureRow("Título, texto de tela e legenda para publicação")
        Text("A seleção de vídeo já funciona. A edição/exportação será adicionada na próxima etapa.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun ToolsScreen(modifier: Modifier, onTool: (String) -> Unit) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Ferramentas inteligentes", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Escolha uma tarefa para começar.", color = Muted)
        listOf(
            "Criar roteiro para vídeo de notícias",
            "Resumir um texto ou documento",
            "Pesquisar um assunto na internet",
            "Organizar minhas tarefas",
            "Criar ideias para redes sociais",
            "Analisar um tema financeiro"
        ).forEach { item ->
            Card(
                modifier = Modifier.fillMaxWidth().clickable { onTool(item) },
                colors = CardDefaults.cardColors(containerColor = Panel)
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, tint = Mint, contentDescription = null)
                    Spacer(Modifier.width(12.dp))
                    Text(item)
                }
            }
        }
    }
}

@Composable
fun FeatureRow(text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("•", color = Mint, fontSize = 20.sp)
        Spacer(Modifier.width(8.dp))
        Text(text, color = Color.White, fontSize = 14.sp)
    }
}

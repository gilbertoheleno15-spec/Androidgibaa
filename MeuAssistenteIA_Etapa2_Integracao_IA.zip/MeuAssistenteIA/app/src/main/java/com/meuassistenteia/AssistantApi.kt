package com.meuassistenteia

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Calls YOUR backend, not the AI provider directly.
 * Set the HTTPS endpoint after deploying the backend.
 * Never embed a private AI API key in the APK.
 */
class AssistantApi(
    private val endpoint: String
) {
    private val http = OkHttpClient.Builder()
        .callTimeout(60, TimeUnit.SECONDS)
        .build()

    fun sendMessage(message: String): Result<String> = runCatching {
        require(endpoint.startsWith("https://")) {
            "Configure um endereço HTTPS seguro para o servidor."
        }
        val json = JSONObject().put("message", message).toString()
        val body = json.toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder()
            .url(endpoint)
            .post(body)
            .build()

        http.newCall(request).execute().use { response ->
            val responseText = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                error("Servidor respondeu com HTTP ${response.code}.")
            }
            val parsed = JSONObject(responseText)
            parsed.optString("reply").ifBlank {
                error("A resposta do servidor não contém o campo 'reply'.")
            }
        }
    }
}
